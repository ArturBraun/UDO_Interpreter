#!/bin/bash
./run_memory.sh py2
./run_speed.sh py2

